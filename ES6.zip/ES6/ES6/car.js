class Car {
    constructor(name, model, price) {
        this.name = name;
        this.model = model;
        this.price = price;
    }
    getCarDetails() {
        console.log('name ' + this.name + " model " + this.model + " prize " + this.price + "car type is " + this.type);
    }
}
class Hundai extends Car {
    constructor(name, model, price, type) {
        super(name, model, price)
        this.type = type;
    }
}

class maruti extends Hundai {
    constructor(name, model, price, type) {
        super(name, model, price)
        this.type = type;
    }
}

var car = new Hundai('hundai', 'i10', 200000, 'sedan');
car.getCarDetails();
var car = new maruti('maruti', '800', 20000, 'sedan');
car.getCarDetails();





















// function emp(name,age,salary) {
//     this.name=name;
//     this.age=age;
//     this.salary=salary;
// }

// emp.prototype = {
//     getDetails:function() {
//         console.log('inside the getDetails');
//         console.log("Name "+this.name+" Age "+ this.age +" salary "+this.salary);
//         return " ";
//     }
// };

// var e=new emp('ramu',22,123456);
// e.getDetails();
