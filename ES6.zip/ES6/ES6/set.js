class abc{

    constructor()
    {
        setTimeout( ()=> { 
            console.log('hello this is setTimeout function 5 sec');
        } , 5000)
    }
}

var a=new abc();