
() => //single line code;

sub = () => { 
        //mulitiple line code
 };

var x = (a,b)=>a+b

 console.log(x(10,20));

var xyz = (x,y)=> {   
                console.log(` the result is ${x+y}`)
                return x+y;
                }  

console.log(xyz(10,20));

function add(x) {
    var a=x;
    console.log(a);
}
add(xyz());