import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structural',
  templateUrl: './structural.component.html',
  styleUrls: ['./structural.component.css']
})
export class StructuralComponent implements OnInit {

  bevrages=['tea','coffee','milk','juice'];

  option:number=1;
  
  json=[
    {'name':'rahul','age':20,'salary':2000},
    {'name':'rahul','age':20,'salary':2000},
    {'name':'rahul','age':20,'salary':2000},
    {'name':'rahul','age':20,'salary':2000},
    {'name':'rahul','age':20,'salary':2000}
    ];

  constructor() { }

  ngOnInit(): void {
  }

}
