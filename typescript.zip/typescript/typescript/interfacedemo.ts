interface Emp {
    name: string;
    age: number;
    salary?: number;
    display?(): string;
}
var emp = { 'name': 'sagar', 'age': 22, 'salary': 20000, 'city': 'blore' };//here the object or interface is not invoked
                                            //it will accept any varibles         
console.log(emp.city);

var emp1: Emp = { 'name': 'sagar', 'age': 22, 'salary': 200000 };      //this will invoke interface varibles 
                                            //json will accept only the varibles which are declared in the interface                            
var emp2: Emp = {
    'name': 'sagar',
    'age': 22,
    display: (): string => {
        return "Hi this is text demo";
    }
};                                           //here the salary varible is optional

console.log('-----------------')
console.log("Employee Name :" + emp1.name);
console.log("Employee age :" + emp1.age);
console.log("Employee Salary :" + emp1.salary);

console.log('-----------------')
console.log("Employee Name :" + emp2.name);
console.log("Employee age :" + emp2.age);
console.log("Employee Details :" + emp2.display());
