let arr=['apple',1,2,true,false,()=>{return 'hello'},10.12, new Date()];

console.log(arr);

let arr1:Array<number>=[1,2,2,3,3,4,4,5,5]; // here array can hold only number type of data

console.log(arr1);
for (const i of arr1) {
    console.log(i);
}