var v = {
    id: 1,
    name: "srinivas",
    city: "banglore",
    pincode: 560066,
    display: function () {
        console.log('demo text');
    }
};
console.log('Json implementation ----------------');
console.log("Name is ".concat(v.name, " and city is ").concat(v.city));
var Manager = /** @class */ (function () {
    function Manager(id, name, city, pincode) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.pincode = pincode;
    }
    Manager.prototype.display = function () {
        console.log(" Hi this is ".concat(this.name, " and i'm in ").concat(this.city));
    };
    return Manager;
}());
console.log('Object implementation ----------------');
var employee = new Manager(1, 'srinivas', 'banglore', 222222);
employee.display();
