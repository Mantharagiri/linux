var arr = ['apple', 1, 2, true, false, function () { return 'hello'; }, 10.12, new Date()];
console.log(arr);
var arr1 = [1, 2, 2, 3, 3, 4, 4, 5, 5]; // here array can hold only number type of data
console.log(arr1);
for (var _i = 0, arr1_1 = arr1; _i < arr1_1.length; _i++) {
    var i = arr1_1[_i];
    console.log(i);
}
