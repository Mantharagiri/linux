interface address {
    city: string;
    pincode: number;
}

interface Employee extends address {
    id: number;
    name: string;
    display(): void;
}

var v: Employee = {
    id: 1,
    name: "srinivas",
    city: "banglore",
    pincode: 560066,
    display: function (): void {
        console.log('demo text')
    }
};
console.log('Json implementation ----------------')
console.log(`Name is ${v.name} and city is ${v.city}`);

class Manager implements Employee {

    id: any;
    name: string;
    city: string;
    pincode: number;

    constructor(id: number, name: string, city: string, pincode: number) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.pincode = pincode;
    }
    display(): void {
        console.log(` Hi this is ${this.name} and i'm in ${this.city}`);
    }
}

console.log('Object implementation ----------------')
var employee:Manager =new Manager(1,'srinivas','banglore',222222);
employee.display();
